package com.example.codechallenge

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
